# Filer lånt fra react-input foreløpig

Dependencies:
<br>
npm install jquery --save
<br>
bootstrap
<br>
chart
<br>
fontawesome
